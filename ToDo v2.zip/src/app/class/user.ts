export class User {

    constructor(
    public pseudo: string,
    public email: string) {}
}
