import { Injectable } from '@angular/core';
import { AuthService } from './auth.service';

import { User } from "../../class/user";

import * as firebase from "firebase";
import DataSnapshot = firebase.database.DataSnapshot;

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private authService: AuthService) { }

  // Enregistrement d'un utilisateur dans la base de données
  createUser(user: User) {

    firebase
      .database()
      .ref("user-list/" + this.authService.currentId())
      .set(user);
  }

  // Récupération d'un utilisateur
  getUser(id: string) {
    // Création d'une promesse pour la récupération d'un utilisateur
    return new Promise((resolve, reject) => {
      firebase
        .database()
        .ref("/user-list/" + id)
        .once("value")
        .then(
          (data: DataSnapshot) => {
            resolve(data.val());
          },
          error => {
            reject(error);
          }
        );
    });
  }

}
