import { Injectable } from '@angular/core';
import * as firebase from 'firebase/app';
import { AngularFireAuth } from "@angular/fire/auth";

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private ngFireAuth: AngularFireAuth) { }

    // Enregistrement d'un utilisateur dans la base de données
    signUpUser(email: string, password: string) {
        return new Promise((resolve, reject) => {
            this.ngFireAuth
                .createUserWithEmailAndPassword(email, password)
                .then(
                    (user) => {
                        resolve(user);
                    },
                    (error) => {
                        reject(error);
                    }
                );
        });
    }

    // Connexion d'un utilisateur par email et mot de passe
    signInUser(email: string, password: string) {
        return new Promise((resolve, reject) => {
            this.ngFireAuth
                .signInWithEmailAndPassword(email, password)
                .then(
                    () => {
                        resolve();
                    },
                    (error)=> {
                        reject(error);
                    }
                );
        });
    }

    // ID de l'utilisateur connecté
    currentId() {
        return firebase.auth().currentUser.uid;
    }
}
