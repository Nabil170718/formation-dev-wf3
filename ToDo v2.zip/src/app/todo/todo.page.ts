import { Component, OnInit } from '@angular/core';
import * as firebase from "firebase";
import { ApiService } from '../services/api/api.service';
import { UserService } from "../services/firebase/user.service";

import { User } from "../class/user";

@Component({
  selector: 'app-todo',
  templateUrl: './todo.page.html',
  styleUrls: ['./todo.page.scss'],
})
export class TodoPage implements OnInit {

  public taches: Object;
  // Utilisateur
  public user: User;

  constructor(private api: ApiService,
              private userService: UserService) {}

  ngOnInit() {

    this.user = { pseudo : '', email: ''};

    let userCurrent = firebase.auth().currentUser;
    // Récupération du profil à partir de l'id
    this.userService.getUser(userCurrent.uid).then(
      (user: User) => {

        this.user = user;
        this.api.getTasks().subscribe(donnees => {
            this.taches = donnees;
            console.log(this.taches);
        });

      }
    );

  }

}
