import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';

import { AuthService } from '../services/firebase/auth.service';

import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})

export class LoginPage implements OnInit {

    public loginForm: FormGroup;

    constructor(
        private formBuilder: FormBuilder,
        private authService: AuthService,
        private router: Router
    ) {}

    // Initialisation du formulaire
    ngOnInit() {
        this.initForm();
    }

    // Initialisation du formulaire
    initForm() {
        this.loginForm = this.formBuilder.group({
            email: ["", [Validators.required, Validators.email]],
            password: [
                "",
                [Validators.required, Validators.pattern(/[0-9a-zA-Z]{6,}/)]
            ]
        });
    }

    onSignin() {
        // Récupération des données du formulaire
        let email = this.loginForm.get("email").value;
        let password = this.loginForm.get("password").value;
        //Connexion de l'utilisateur
        this.authService.signInUser(email, password).then(
            () => {
                this.router.navigate(["/todo"]);
            },
            error => {
                console.log("PROBLEME");
            }
        );

    }
}
