import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { AuthService } from '../services/firebase/auth.service';

import { UserService } from "../services/firebase/user.service";
import { User } from "../class/user";

import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {
    // Formulaire (méthode réactive)
    public registerForm: FormGroup;
    // Utilisateur
    private user: User;

  constructor(
    private authService: AuthService,
    private userService: UserService,
    private formBuilder: FormBuilder,
    private router: Router ) {}

    ngOnInit() {
        // Initialisation du formulaire
        this.initForm();
    }

    // Initialisation du formulaire
    initForm() {
        this.registerForm = this.formBuilder.group({
            // Email requis, type email demandé
            email: ["", [Validators.required, Validators.email]],
            // Mot de passe requis, au moins 6 caractères
            password: [
                "",
                [
                    Validators.required,
                    Validators.pattern(/[0-9a-zA-Z]{6,}/),
                    Validators.minLength(6),
                ]
            ],
            // Pseudo requis, au moins 6 caractères
            pseudo: [
                "",
                [
                    Validators.required,
                    Validators.pattern(/[0-9a-zA-Z]{6,}/),
                    Validators.minLength(6),
                ]
            ]
        });
    }


    // Enregistrement de l'utilisateur et de ses informations
    onSaveUser() {
        // Récupération des données du formulaire
        let email = this.registerForm.get("email").value;
        let password = this.registerForm.get("password").value;
        let pseudo = this.registerForm.get("pseudo").value;
        // Assignation des données recueillies à l'objet l'utilisateur
        this.user = new User(
            pseudo,
            email
        );

        // Enregistrement de l'utilisateur après l'enregistrement de l'authentification
        this.authService.signUpUser(email, password).then(
            () => {
                // Enregistrement des données de l'utilisateur par le noeud de son ID
                this.userService.createUser(this.user);
                //let id = this.authService.currentId();
                // Redirection vers la page principale
                this.router.navigate(["/todo"]);
            },
            (error) => {
                // Affichage des erreurs
                console.log(error);
            }
        );
    }
}
