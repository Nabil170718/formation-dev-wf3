export const environment = {
  production: true,
  firebase : {
  apiKey: "AIzaSyCy62NV9e-muEhg7P2LNWGZq-axR7DyHww",
  authDomain: "ionic-wf3.firebaseapp.com",
  databaseURL: "https://ionic-wf3.firebaseio.com",
  projectId: "ionic-wf3",
  storageBucket: "ionic-wf3.appspot.com",
  messagingSenderId: "906541662406",
  appId: "1:906541662406:web:47465a336c585b38"
 }
};
