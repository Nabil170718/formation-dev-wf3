// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase : {
  apiKey: "AIzaSyCy62NV9e-muEhg7P2LNWGZq-axR7DyHww",
  authDomain: "ionic-wf3.firebaseapp.com",
  databaseURL: "https://ionic-wf3.firebaseio.com",
  projectId: "ionic-wf3",
  storageBucket: "ionic-wf3.appspot.com",
  messagingSenderId: "906541662406",
  appId: "1:906541662406:web:47465a336c585b38"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
